<footer class="site-footer">
    <!-- Add any additional footer content here -->
    <div class="custom-footer-links">
        <a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>">Privacy Policy</a>
        <a href="<?php echo esc_url( home_url( '/about-us/' ) ); ?>">About Us</a>
        <a href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>">Contact Us</a>
        <a href="<?php echo esc_url( home_url( '/terms-and-conditions/' ) ); ?>">Terms and Conditions</a>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>