<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo get_bloginfo('name'); ?></title>
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
  <header class="site-header">
    <h1 class="site-title"><?php echo get_bloginfo('name'); ?></h1>
    <!-- Add any additional header content here -->
 <script src="https://code.responsivevoice.org/responsivevoice.js?key=5geDqmK4"></script>
  </header>