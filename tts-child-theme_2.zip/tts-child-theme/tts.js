document.querySelector('#speak-button').addEventListener('click', (event) => {
  event.preventDefault();

  const text = document.querySelector('#text').value;
  const language = document.querySelector('#language').value;
  const gender = document.querySelector('#gender').value;
  const rate = document.querySelector('#rate').value;
  const pitch = document.querySelector('#pitch').value;
  const format = document.querySelector('#format').value;

  const url = `https://texttospeech.googleapis.com/v1/textToSpeech:synthesize?key=${API_KEY}`;

  const requestBody = {
    input: {
      text: text
    },
    voice: {
      language: language,
      gender: gender,
      name: `${language}-${gender}-${rate}-${pitch}`
    },
    audioConfig: {
      audioEncoding: format
    }
  };

  const requestOptions = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(requestBody)
  };

  fetch(url, requestOptions)
    .then((response) => response.json())
    .then((data) => {
      const audioBlob = new Blob([data.audioContent], { type: `audio/${format}` });
      const audioUrl = URL.createObjectURL(audioBlob);

      const audioElement = document.createElement('audio');
      audioElement.src = audioUrl;
      audioElement.play();

      // Add download functionality
      const downloadButton = document.querySelector('#download-button');
      downloadButton.addEventListener('click', () => {
        const filename = 'audio.' + format;
        downloadFile(audioBlob, filename);
      });
    })
    .catch((error) => {
      console.error('Error:', error);
    });
});
