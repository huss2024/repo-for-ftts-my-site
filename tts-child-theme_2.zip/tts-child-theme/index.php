<?php
/* Template Name: TTS Template */
get_header();
?>

<main id="primary" class="site-main">
  <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
      <h1 class="entry-title">Text to Speech Converter</h1>
    </header><!-- .entry-header -->

    <div class="entry-content">
      <?php get_template_part( 'template-parts/tts-form' ); ?>
    </div><!-- .entry-content -->
  </article><!-- #post-<?php the_ID(); ?> -->
</main><!-- #primary -->

<?php get_footer(); ?>
