<?php
/*
Template Name: TTS Template
*/
get_header();
?>

<main id="primary" class="site-main">
  <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
      <h1 class="entry-title">Text to Speech Converter</h1>
    </header><!-- .entry-header -->

    <div class="entry-content">
      <form id="tts-form">
        <label for="text">Text to synthesize:</label>
        <textarea id="text" name="text" placeholder="Enter text..."></textarea>

        <label for="language">Language:</label>
        <select id="language" name="language">
          <option value="en-US">English (US)</option>
          <option value="en-GB">English (GB)</option>
          <option value="ar-SA">Arabic (SA)</option>
          <option value="es-ES">Spanish (Spain)</option>
          <option value="fr-FR">French (France)</option>
          <option value="de-DE">German (Germany)</option>
          <option value="it-IT">Italian (Italy)</option>
          <option value="ja-JP">Japanese (Japan)</option>
          <option value="ko-KR">Korean (Korea)</option>
          <option value="zh-CN">Chinese (China)</option>
          <option value="hi-IN">Hindi (India)</option>
          <option value="ru-RU">Russian (Russia)</option>
          <option value="pt-BR">Portuguese (Brazil)</option>
          <option value="nl-NL">Dutch (Netherlands)</option>
          <option value="sv-SE">Swedish (Sweden)</option>
          <!-- Add additional languages here -->
        </select>

        <label for="gender">Gender:</label>
        <select id="gender" name="gender">
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>

        <label for="rate">Rate:</label>
        <select id="rate" name="rate">
          <option value="0.25">0.25x</option>
          <option value="0.5">0.5x</option>
          <option value="0.75">0.75x</option>
          <option value="1" selected>1x</option>
          <option value="1.25">1.25x</option>
          <option value="1.5">1.5x</option>
          <option value="1.75">1.75x</option>
          <option value="2">2x</option>
        </select>

        <label for="pitch">Pitch:</label>
        <select id="pitch" name="pitch">
          <option value="-12">Very low</option>
          <option value="-8">Low</option>
          <option value="-4">Slightly low</option>
          <option value="0" selected>Normal</option>
          <option value="4">Slightly high</option>
          <option value="8">High</option>
          <option value="12">Very high</option>
        </select>

        <label for="format">Download Format:</label>
        <select id="format" name="format">
          <option value="mp3">MP3</option>
          <option value="wav">WAV</option>
          <option value="ogg">OGG</option>
          <option value="flac">FLAC</option>
          <option value="aac">AAC</option>
          <!-- Add additional formats here -->
        </select>

        <button id="speak-button" type="submit">Speak</button>
        <button id="download-button" type="button">Download</button>
      </form>
    </div><!-- .entry-content -->
  </article><!-- #post-<?php the_ID(); ?> -->
</main><!-- #primary -->

<?php get_footer(); ?>