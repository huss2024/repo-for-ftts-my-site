<?php
function tts_enqueue_scripts() {
  wp_enqueue_script( 'tts-script', get_stylesheet_directory_uri() . '/tts.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'tts_enqueue_scripts' );

// Add privacy policy, about us, contact us, and terms and conditions buttons to the footer
function add_custom_footer_links() {
  echo '<div class="custom-footer-links">';
  echo '<a href="' . esc_url( home_url( '/privacy-policy/' ) ) . '">Privacy Policy</a>';
  echo '<a href="' . esc_url( home_url( '/about-us/' ) ) . '">About Us</a>';
  echo '<a href="' . esc_url( home_url( '/contact-us/' ) ) . '">Contact Us</a>';
  echo '<a href="' . esc_url( home_url( '/terms-and-conditions/' ) ) . '">Terms and Conditions</a>';
  echo '</div>';
}
add_action( 'wp_footer', 'add_custom_footer_links' );
?>