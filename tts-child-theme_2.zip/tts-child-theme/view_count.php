<?php
// Increment the view count for a post
function increment_view_count($post_id) {
  $current_count = get_post_meta($post_id, 'view_count', true);
  $new_count = $current_count + 1;
  update_post_meta($post_id, 'view_count', $new_count);
}

// Add a view count column to the admin posts list
add_filter( 'manage_posts_columns', 'add_view_count_column' );
function add_view_count_column( $columns ) {
  $columns['view_count'] = 'View Count';
  return $columns;
}

// Display the view count in the admin posts list
add_action( 'manage_posts_custom_column', 'display_view_count_column', 10, 2 );
function display_view_count_column( $column_name, $post_id ) {
  if ( $column_name == 'view_count' ) {
    $view_count = get_post_meta($post_id, 'view_count', true);
    echo $view_count;
  }
}
?>